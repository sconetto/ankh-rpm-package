# !/bin/bash
# Author: João Pedro Sconetto - sconetto.joao@gmail.com
# Date: 22/05/2017

DOCS="./doc-pak/"
SRC="./src/"
INC="./include/"

sudo make uninstall

./cleanup.sh

sleep 1
