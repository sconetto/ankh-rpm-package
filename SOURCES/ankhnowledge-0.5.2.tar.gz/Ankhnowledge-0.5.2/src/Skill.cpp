#include "Skill.h"

Skill::Skill() {}

Skill::~Skill() {}

